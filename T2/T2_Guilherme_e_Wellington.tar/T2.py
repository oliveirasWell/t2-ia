"""
Trabalho T2 de IA
Autores:
Guilherme Augusto Defalque
Wellington de Oliveira dos Santos

Compilar: python T2.py training.csv sorted_test.csv
"""
import sys
import numpy as np
from sklearn.neighbors import KNeighborsRegressor
from sklearn.cross_validation import train_test_split
from sklearn.metrics.metrics import zero_one_loss
from sklearn.metrics import confusion_matrix
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.naive_bayes import GaussianNB
import random
from sklearn import svm, grid_search, datasets
from math import sqrt
from sklearn.svm import SVR

""" Colocacao 649"""

def load_dataset_test(filename):
    f = open(filename)

    ids = []
    x = []

    for line in f:
        v = line.rstrip('\n').split(',')
        if(not(v[0] == 'PIDN')):
            ids.append(v[0])

            a = [float (z) for z in v[1:-1]]     
            
            if(v[-1] == 'Topsoil'):
                a.append(1)
            else:
                a.append(0)

            x.append(a)
    return x, ids

def load_dataset(filename):
    f = open(filename)

    ids = []
    x = []
    y_Ca = []
    y_P = []
    y_pH = []
    y_SOC = []
    y_Sand = []

    for line in f:
        v = line.rstrip('\n').split(',')
        if(not(v[0] == 'PIDN')):

            a = [float(z) for z in v[1:-6]]         
            
            if(v[-6] == 'Topsoil'):
                a.append(1)
            else:
                a.append(0)

            x.append(a)

            y_Ca.append(float(v[-5]))
            y_P.append(float(v[-4]))
            y_pH.append(float(v[-3]))
            y_SOC.append(float(v[-2]))
            y_Sand.append(float(v[-1]))     

    return x, y_Ca, y_P, y_pH, y_SOC, y_Sand, 

if __name__ == '__main__':

    x_train, y_Ca, y_P, y_pH, y_SOC, y_Sand = load_dataset(sys.argv[1])
    x_test, iDs = load_dataset_test(sys.argv[2])

    y_vector = [y_Ca, y_P, y_pH, y_SOC, y_Sand]
    defaultOut = []  

    total_relative_error = 0
    total_absolute_error = 0

    for i in xrange(len(y_vector)):
        x_trainSplited, x_testSplited, y_trainSplited, y_testSplited = train_test_split( x_train, y_vector[i], test_size=0.05, random_state=0)

        clf= SVR(kernel='linear', degree=3, gamma=0.0, epsilon=0.05)
        
        tam = len(y_trainSplited)
    
        inc = tam/5
        count = inc

        print("Iteracao: " + repr(i+1) )

        while count < tam:
        
            clf.fit(x_trainSplited[:count], y_trainSplited[:count])
            y_pred = clf.predict(x_testSplited)
            count += inc
            a = len(y_trainSplited)

            b = zero_one_loss(y_testSplited, y_pred)
            errorTax = float(a/b)

        print("Mean Squared Error: "+ repr(mean_squared_error(y_testSplited, y_pred)))
        print("Mean Absolute Error: "+ repr(mean_absolute_error(y_testSplited, y_pred)))
        total_relative_error = total_relative_error + mean_squared_error(y_testSplited, y_pred)
        total_absolute_error = total_absolute_error + mean_absolute_error(y_testSplited, y_pred)
        
        y_pred = clf.predict(x_test)
        defaultOut.append(y_pred)

    f = open('sample_submission.csv','w')
    f.write("PIDN,Ca,P,pH,SOC,Sand"+'\n')
    for i in xrange(len(iDs)):
        f.write( iDs[i] + "," + repr(defaultOut[0][i]) + "," + repr(defaultOut[1][i]) + "," + repr(defaultOut[2][i]) + "," + repr(defaultOut[3][i]) + "," + repr(defaultOut[4][i]) + '\n')

    f.close()
    root = sqrt(727)
    total_relative_error = total_relative_error/(5*root)
    total_absolute_error = total_absolute_error/5
    
    print total_relative_error
    print total_absolute_error    
